package ph.edu.dlsu.lbycpei.caferecommmendationsystem;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CafeSystem {

    private Menu menu = new Menu();
    private RecommendationGraph graph = new RecommendationGraph();
    private Similarity similarity = new Similarity();
    private Order currentOrder = new Order();
    private final Inventory inventory = new Inventory();


    private String loggedInUsername = null;
    private User currentUser = null;

    public Inventory getInventory() { return inventory; }


    public CafeSystem() {
        FileDatabaseManager.initialize();
        loadSampleMenu();
        loadSampleInventory();
    }

    private void loadSampleMenu() {
        menu.addItem(new MenuItem("Matcha Latte", 150));
        menu.addItem(new MenuItem("Espresso", 120));
        menu.addItem(new MenuItem("Dubai Chocolate Brownie", 95));
        menu.addItem(new MenuItem("Iced Tea", 100));
        menu.addItem(new MenuItem("Lemonade", 80));
    }

    private void loadSampleInventory() {
        inventory.addItem(new InventoryItem("Matcha Latte", 50));
        inventory.addItem(new InventoryItem("Espresso", 30));
        inventory.addItem(new InventoryItem("Dubai Chocolate Brownie", 100));
        inventory.addItem(new InventoryItem("Iced Tea", 20));
        inventory.addItem(new InventoryItem("Lemonade", 20));
    }

    public void setLoggedInUsername(String username) {
        this.loggedInUsername = username;
    }

    public String getLoggedInUsername() {
        return loggedInUsername;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean loginUser(String username, String password) {
        boolean valid = FileDatabaseManager.validateLogin(username, password);

        if (valid) {
            setLoggedInUsername(username);

            // Load full user object + order history
            currentUser = FileDatabaseManager.loadUser(username);
        }

        return valid;
    }


    public boolean registerUser(String username, String password) {
        return FileDatabaseManager.registerUser(username, password);
    }

    public void logoutUser() {
        loggedInUsername = null;
        startNewOrder();
    }


    public void startNewOrder() {
        this.currentOrder = new Order();
    }

    public Order getCurrentOrder() {
        return this.currentOrder;
    }

    public boolean addItemToOrder(String itemName) {

        InventoryItem stock = inventory.getItemByName(itemName);
        if (stock == null) {
            System.out.println("Item does not exist in inventory.");
            return false;
        }

        if (stock.getQuantity() <= 0) {
            System.out.println("OUT OF STOCK: " + itemName);
            return false;
        }

        MenuItem item = menu.getItemByName(itemName);
        if (item != null) {
            currentOrder.addItem(item);
            return true;
        }

        return false;
    }

    public List<String> getRecommendations() {
        HashSet<String> recommendations = new HashSet<>();

        for (MenuItem item : currentOrder.getItems()) {
            String itemName = item.getName();

            String paired = graph.getTopRecommendation(itemName);
            if (paired != null
                    && menu.getItemByName(paired) != null
                    && !currentOrder.containsItem(paired)) {
                recommendations.add(paired);
            }

            var list = similarity.getSimilarItems(itemName);
            for (String sim : list) {
                if (menu.getItemByName(sim) != null
                        && !currentOrder.containsItem(sim)) {
                    recommendations.add(sim);
                }
            }
        }
        return new ArrayList<>(recommendations);
    }

    public boolean addRecommendedItem(String name) {
        MenuItem recItem = menu.getItemByName(name);
        if (recItem != null) {
            currentOrder.addItem(recItem);
            return true;
        }
        return false;
    }

    public String finalizeOrder() {

        if (!currentOrder.getItems().isEmpty()) {
            for (MenuItem item : currentOrder.getItems()) {
                inventory.reduceStock(item.getName());
            }
            graph.updateGraph(currentOrder.getItems());

            // Save order to DB
            if (loggedInUsername != null) {
                FileDatabaseManager.saveOrder(loggedInUsername, currentOrder);
                if (currentUser != null) currentUser.addOrderToHistory(currentOrder);
            }
        }

        String receiptText = Receipt.getReceiptText(currentOrder);

        startNewOrder();

        return receiptText;
    }


    public List<MenuItem> getMenuItems() {
        return menu.getItems();
    }
}
