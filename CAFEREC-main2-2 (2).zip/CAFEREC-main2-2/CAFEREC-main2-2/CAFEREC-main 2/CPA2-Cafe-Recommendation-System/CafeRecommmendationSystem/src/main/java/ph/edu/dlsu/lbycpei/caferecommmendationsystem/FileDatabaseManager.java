package ph.edu.dlsu.lbycpei.caferecommmendationsystem;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class FileDatabaseManager {

    private static final String USERS_FILE = "users.txt";
    private static final String ORDERS_FOLDER = "orders";

    public static void initialize() {
        try {
            File users = new File(USERS_FILE);
            if (!users.exists()) users.createNewFile();

            File folder = new File(ORDERS_FOLDER);
            if (!folder.exists()) folder.mkdir();

            registerUser("admin", "admin");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // USER REGISTRATION

    public static boolean registerUser(String username, String password) {
        Map<String, String> users = loadAllUsers();

        if (users.containsKey(username)) {
            return false; // username exists
        }

        try (FileWriter fw = new FileWriter(USERS_FILE, true)) {
            fw.write(username + "|" + password + "\n");
        } catch (IOException e) { e.printStackTrace(); }

        return true;
    }

    // Logincheck

    public static boolean validateLogin(String username, String password) {
        Map<String, String> users = loadAllUsers();
        return users.containsKey(username) && users.get(username).equals(password);
    }

    private static Map<String, String> loadAllUsers() {
        Map<String, String> map = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    map.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }

        return map;
    }

    // Save order history

    public static void saveOrder(String username, Order order) {
        String filePath = ORDERS_FOLDER + "/" + username + ".txt";
        String timestamp = LocalDateTime.now().toString();

        try (FileWriter fw = new FileWriter(filePath, true)) {
            for (MenuItem item : order.getItems()) {
                fw.write(timestamp + "|" + item.getName() + "|" + item.getPrice() + "\n");
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    // LOAD USER + ORDER HISTORY

    public static User loadUser(String username) {
        Map<String, String> users = loadAllUsers();

        if (!users.containsKey(username)) return null;

        User user = new User(username, users.get(username));

        String filePath = ORDERS_FOLDER + "/" + username + ".txt";

        File f = new File(filePath);
        if (!f.exists()) return user;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            Map<String, Order> orderGroups = new HashMap<>();

            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|");
                if (p.length != 3) continue;

                String timestamp = p[0];
                String itemName = p[1];
                double price = Double.parseDouble(p[2]);

                orderGroups.putIfAbsent(timestamp, new Order());
                orderGroups.get(timestamp).addItem(new MenuItem(itemName, price));
            }

            for (Order o : orderGroups.values()) {
                user.addOrderToHistory(o);
            }

        } catch (IOException e) { e.printStackTrace(); }

        return user;
    }
}
