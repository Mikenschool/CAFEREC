package ph.edu.dlsu.lbycpei.caferecommmendationsystem;

public class Main {
    public static void main(String[] args) {
        CafeSystem cafe = new CafeSystem();
        cafe.run();
    }
}